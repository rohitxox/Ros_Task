from setuptools import setup, find_packages
import os
from glob import glob

package_name = 'alphabet_publisher_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),  # Exclude the test directory
    data_files=[
        (os.path.join('share', package_name), glob('launch/*.launch.py')),
        (os.path.join('share', package_name), glob('msg/*.msg')),  # Include message files
        (os.path.join('share', 'ament_index', 'resource_index', 'packages'),
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='nightfurry',
    maintainer_email='nightfurry@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'alphabet_publisher = alphabet_publisher_pkg.alphabet_publisher:main',
        ],
    },
)
