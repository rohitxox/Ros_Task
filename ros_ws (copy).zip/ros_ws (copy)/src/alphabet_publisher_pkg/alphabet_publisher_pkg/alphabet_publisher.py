import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class AlphabetPublisher(Node):

    def __init__(self):
        super().__init__('alphabet_publisher')
        self.publisher_ = self.create_publisher(String, 'alphabet_topic', 10)
        self.alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        self.index = 0
        self.timer = self.create_timer(2.0, self.publish_letter)  # every 2 seconds

    def publish_letter(self):
        msg = String()
        msg.data = self.alphabet[self.index]
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%s"' % msg.data)
        self.index = (self.index + 1) % len(self.alphabet)  # loop through alphabet

def main(args=None):
    rclpy.init(args=args)
    alphabet_publisher = AlphabetPublisher()
    rclpy.spin(alphabet_publisher)
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically when the garbage collector destroys the node object)
    alphabet_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
