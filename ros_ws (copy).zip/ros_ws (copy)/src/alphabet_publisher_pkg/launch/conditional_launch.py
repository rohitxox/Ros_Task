from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import LogInfo
import datetime

def generate_launch_description():
    node_to_launch = Node(
        package='alphabet_publisher_pkg',
        executable='alphabet_publisher',
        name='alphabet_publisher_node'
    )

    current_time = datetime.datetime.now().time()
    target_hour = 23
    target_minute = 10

    # Log the current time and target time for clarity
    log_current_time = LogInfo(msg=f"Current time: {current_time.hour}:{current_time.minute}")
    log_target_time = LogInfo(msg=f"Expected launch time: {target_hour}:{target_minute}")

    # Check if the current time matches the target time
    if current_time.hour == target_hour and current_time.minute == target_minute:
        action = LogInfo(msg="Launching node because it's exactly 23:10")
        return LaunchDescription([log_current_time, log_target_time, action, node_to_launch])
    else:
        action = LogInfo(msg="It is not the right time, so not launching the specific node")
        return LaunchDescription([log_current_time, log_target_time, action])


