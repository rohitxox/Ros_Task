import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
import time

class OdomSubscriber(Node):
    def __init__(self):
        super().__init__('odom_subscriber')
        self.subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.last_print_time = time.time()
        self.print_interval = 1.0  # Adjust print frequency in seconds

    def odom_callback(self, msg):
        current_time = time.time()
        if (current_time - self.last_print_time) >= self.print_interval:
            position = msg.pose.pose.position
            orientation = msg.pose.pose.orientation
            # Print a simplified and easy-to-read string
            self.get_logger().info(
                f"x: {position.x:.2f}\n"
                f"y: {position.y:.2f}\n"
                f"z: {position.z:.2f}\n"
                "angular:\n"
                f"x: {orientation.x:.2f}\n"
                f"y: {orientation.y:.2f}\n"
                f"z: {orientation.z:.2f}\n"
                f"w: {orientation.w:.2f}\n"
            )
            self.last_print_time = current_time  # Update the last print time

def main(args=None):
    rclpy.init(args=args)
    odom_subscriber = OdomSubscriber()
    try:
        rclpy.spin(odom_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        odom_subscriber.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
