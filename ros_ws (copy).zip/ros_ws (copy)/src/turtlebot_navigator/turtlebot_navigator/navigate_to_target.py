import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class InteractiveNavigator(Node):
    def __init__(self):
        super().__init__('interactive_navigator')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)

    def move_forward(self, distance):
        # Set a constant speed and calculate the duration
        speed = 1.2  # meters per second
        duration = distance / speed
        move_command = Twist()
        move_command.linear.x = speed
        self.get_logger().info(f'Moving forward for {distance} meters.')
        self.publisher_.publish(move_command)
        rclpy.spin_once(self, timeout_sec=duration)
        self.stop_moving()

    def turn_right(self):
        # Calibrate these values to achieve an accurate 90-degree turn
        angular_speed = 0.5  # radians per second
        duration_for_90_deg_turn = 3.5  # Adjust this duration based on your robot's actual performance

        turn_command = Twist()
        turn_command.angular.z = -angular_speed  # Negative for turning right
        self.get_logger().info('Turning right 90 degrees.')
        self.publisher_.publish(turn_command)
        rclpy.spin_once(self, timeout_sec=duration_for_90_deg_turn)
        self.stop_moving()

    def turn_left(self):
        # Calibrate these values to achieve an accurate 90-degree turn
        angular_speed = 0.5  # radians per second
        duration_for_90_deg_turn = 3.5  # Adjust this duration based on your robot's actual performance

        turn_command = Twist()
        turn_command.angular.z = angular_speed  # Negative for turning right
        self.get_logger().info('Turning Left 90 degrees.')
        self.publisher_.publish(turn_command)
        rclpy.spin_once(self, timeout_sec=duration_for_90_deg_turn)
        self.stop_moving()

    def stop_moving(self):
        self.publisher_.publish(Twist())  # Publish a zeroed Twist message to stop the robot

def main(args=None):
    rclpy.init(args=args)
    navigator = InteractiveNavigator()

    try:
        while rclpy.ok():
            command = input("Enter command ('forward + distance' or 'right' or 'left'): ").split()

            if command[0] == 'forward':
                distance = float(command[1])
                navigator.move_forward(distance)
            elif command[0] == 'right':
                navigator.turn_right()
            elif command[0] == 'left':
                navigator.turn_left()
            else:
                navigator.get_logger().info('Invalid command')

    except KeyboardInterrupt:
        pass
    finally:
        navigator.stop_moving()
        navigator.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
