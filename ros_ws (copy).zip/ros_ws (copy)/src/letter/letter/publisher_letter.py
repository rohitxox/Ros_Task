import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import sys

class LetterPublisher(Node):

    def __init__(self, start_letter='a'):
        super().__init__('letter_publisher')
        self.publisher_ = self.create_publisher(String, 'letter_topic', 10)
        self.timer_period = 1  # seconds
        self.timer = self.create_timer(self.timer_period, self.publish_letter)
        self.current_letter = start_letter

    def publish_letter(self):
        msg = String()
        msg.data = self.current_letter
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: {self.current_letter}')
        # Update to next letter, wrap from 'z' to 'a'
        self.current_letter = chr((ord(self.current_letter) - 97 + 1) % 26 + 97)

def main(args=None):
    rclpy.init(args=args)

    # Accept the starting letter as a command line argument
    start_letter = sys.argv[1] if len(sys.argv) > 1 else 'a'
    
    publisher = LetterPublisher(start_letter)
    rclpy.spin(publisher)
    publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
