# wait_and_launch.py

import launch
from launch import LaunchDescription
from launch.actions import OpaqueFunction
import time
from datetime import datetime, time as dt_time

def wait_and_launch(context, *args, **kwargs):
    node_to_launch = kwargs['node']
    launch_time = kwargs['launch_time']  # Should be a datetime.time object
    
    while datetime.now().time() < launch_time:
        time.sleep(0.5)
    
    print(f"It's now {launch_time}, launching the node!")
    return [node_to_launch]

def generate_launch_description():
    # Define the node to launch
    node = Node(
        package='letter',  
        executable='publisher_letter',  
        name='letter_publisher' 
    )
    
    # Define the time to launch the node
    launch_time = dt_time(15,22)  

    # Return the LaunchDescription, calling the wait function before launch
    return LaunchDescription([
        OpaqueFunction(function=wait_and_launch, kwargs={'node': node, 'launch_time': launch_time}),
    ])
