from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('node_name', default_value='your_node', description='The node to launch'),
        LogInfo(msg="Launching the node..."),
        Node(
            package='letter',
            executable=LaunchConfiguration('node_name'),
            name='your_specific_node'
        )
    ])
