// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__POSITION_FEEDBACK_HPP_
#define ROBOT_INTERFACE__MSG__POSITION_FEEDBACK_HPP_

#include "robot_interface/msg/detail/position_feedback__struct.hpp"
#include "robot_interface/msg/detail/position_feedback__builder.hpp"
#include "robot_interface/msg/detail/position_feedback__traits.hpp"

#endif  // ROBOT_INTERFACE__MSG__POSITION_FEEDBACK_HPP_
