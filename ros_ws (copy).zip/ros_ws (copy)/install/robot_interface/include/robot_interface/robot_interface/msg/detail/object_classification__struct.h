// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interface:msg/ObjectClassification.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__STRUCT_H_
#define ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'label'
#include "rosidl_runtime_c/string.h"
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ObjectClassification in the package robot_interface.
/**
  * ObjectClassification.msg
 */
typedef struct robot_interface__msg__ObjectClassification
{
  rosidl_runtime_c__String label;
  double probability;
  /// Time Stamp
  std_msgs__msg__Header header;
  int64_t x_min;
  int64_t y_min;
  int64_t x_max;
  int64_t y_max;
} robot_interface__msg__ObjectClassification;

// Struct for a sequence of robot_interface__msg__ObjectClassification.
typedef struct robot_interface__msg__ObjectClassification__Sequence
{
  robot_interface__msg__ObjectClassification * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interface__msg__ObjectClassification__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__STRUCT_H_
