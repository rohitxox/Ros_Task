// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from robot_interface:msg/PositionFeedback.idl
// generated code does not contain a copyright notice
#include "robot_interface/msg/detail/position_feedback__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
robot_interface__msg__PositionFeedback__init(robot_interface__msg__PositionFeedback * msg)
{
  if (!msg) {
    return false;
  }
  // speed
  // torque
  // position
  // voltage
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    robot_interface__msg__PositionFeedback__fini(msg);
    return false;
  }
  return true;
}

void
robot_interface__msg__PositionFeedback__fini(robot_interface__msg__PositionFeedback * msg)
{
  if (!msg) {
    return;
  }
  // speed
  // torque
  // position
  // voltage
  // header
  std_msgs__msg__Header__fini(&msg->header);
}

bool
robot_interface__msg__PositionFeedback__are_equal(const robot_interface__msg__PositionFeedback * lhs, const robot_interface__msg__PositionFeedback * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // speed
  if (lhs->speed != rhs->speed) {
    return false;
  }
  // torque
  if (lhs->torque != rhs->torque) {
    return false;
  }
  // position
  if (lhs->position != rhs->position) {
    return false;
  }
  // voltage
  if (lhs->voltage != rhs->voltage) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  return true;
}

bool
robot_interface__msg__PositionFeedback__copy(
  const robot_interface__msg__PositionFeedback * input,
  robot_interface__msg__PositionFeedback * output)
{
  if (!input || !output) {
    return false;
  }
  // speed
  output->speed = input->speed;
  // torque
  output->torque = input->torque;
  // position
  output->position = input->position;
  // voltage
  output->voltage = input->voltage;
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  return true;
}

robot_interface__msg__PositionFeedback *
robot_interface__msg__PositionFeedback__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  robot_interface__msg__PositionFeedback * msg = (robot_interface__msg__PositionFeedback *)allocator.allocate(sizeof(robot_interface__msg__PositionFeedback), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(robot_interface__msg__PositionFeedback));
  bool success = robot_interface__msg__PositionFeedback__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
robot_interface__msg__PositionFeedback__destroy(robot_interface__msg__PositionFeedback * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    robot_interface__msg__PositionFeedback__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
robot_interface__msg__PositionFeedback__Sequence__init(robot_interface__msg__PositionFeedback__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  robot_interface__msg__PositionFeedback * data = NULL;

  if (size) {
    data = (robot_interface__msg__PositionFeedback *)allocator.zero_allocate(size, sizeof(robot_interface__msg__PositionFeedback), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = robot_interface__msg__PositionFeedback__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        robot_interface__msg__PositionFeedback__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
robot_interface__msg__PositionFeedback__Sequence__fini(robot_interface__msg__PositionFeedback__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      robot_interface__msg__PositionFeedback__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

robot_interface__msg__PositionFeedback__Sequence *
robot_interface__msg__PositionFeedback__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  robot_interface__msg__PositionFeedback__Sequence * array = (robot_interface__msg__PositionFeedback__Sequence *)allocator.allocate(sizeof(robot_interface__msg__PositionFeedback__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = robot_interface__msg__PositionFeedback__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
robot_interface__msg__PositionFeedback__Sequence__destroy(robot_interface__msg__PositionFeedback__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    robot_interface__msg__PositionFeedback__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
robot_interface__msg__PositionFeedback__Sequence__are_equal(const robot_interface__msg__PositionFeedback__Sequence * lhs, const robot_interface__msg__PositionFeedback__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!robot_interface__msg__PositionFeedback__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
robot_interface__msg__PositionFeedback__Sequence__copy(
  const robot_interface__msg__PositionFeedback__Sequence * input,
  robot_interface__msg__PositionFeedback__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(robot_interface__msg__PositionFeedback);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    robot_interface__msg__PositionFeedback * data =
      (robot_interface__msg__PositionFeedback *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!robot_interface__msg__PositionFeedback__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          robot_interface__msg__PositionFeedback__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!robot_interface__msg__PositionFeedback__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
