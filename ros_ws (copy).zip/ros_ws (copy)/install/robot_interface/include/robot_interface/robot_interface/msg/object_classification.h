// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interface:msg/ObjectClassification.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__OBJECT_CLASSIFICATION_H_
#define ROBOT_INTERFACE__MSG__OBJECT_CLASSIFICATION_H_

#include "robot_interface/msg/detail/object_classification__struct.h"
#include "robot_interface/msg/detail/object_classification__functions.h"
#include "robot_interface/msg/detail/object_classification__type_support.h"

#endif  // ROBOT_INTERFACE__MSG__OBJECT_CLASSIFICATION_H_
