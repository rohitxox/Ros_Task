// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interface:msg/PositionFeedback.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__POSITION_FEEDBACK_H_
#define ROBOT_INTERFACE__MSG__POSITION_FEEDBACK_H_

#include "robot_interface/msg/detail/position_feedback__struct.h"
#include "robot_interface/msg/detail/position_feedback__functions.h"
#include "robot_interface/msg/detail/position_feedback__type_support.h"

#endif  // ROBOT_INTERFACE__MSG__POSITION_FEEDBACK_H_
