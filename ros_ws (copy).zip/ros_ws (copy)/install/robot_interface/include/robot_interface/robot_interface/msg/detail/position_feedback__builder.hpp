// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interface:msg/PositionFeedback.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__DETAIL__POSITION_FEEDBACK__BUILDER_HPP_
#define ROBOT_INTERFACE__MSG__DETAIL__POSITION_FEEDBACK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interface/msg/detail/position_feedback__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interface
{

namespace msg
{

namespace builder
{

class Init_PositionFeedback_header
{
public:
  explicit Init_PositionFeedback_header(::robot_interface::msg::PositionFeedback & msg)
  : msg_(msg)
  {}
  ::robot_interface::msg::PositionFeedback header(::robot_interface::msg::PositionFeedback::_header_type arg)
  {
    msg_.header = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interface::msg::PositionFeedback msg_;
};

class Init_PositionFeedback_voltage
{
public:
  explicit Init_PositionFeedback_voltage(::robot_interface::msg::PositionFeedback & msg)
  : msg_(msg)
  {}
  Init_PositionFeedback_header voltage(::robot_interface::msg::PositionFeedback::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_PositionFeedback_header(msg_);
  }

private:
  ::robot_interface::msg::PositionFeedback msg_;
};

class Init_PositionFeedback_position
{
public:
  explicit Init_PositionFeedback_position(::robot_interface::msg::PositionFeedback & msg)
  : msg_(msg)
  {}
  Init_PositionFeedback_voltage position(::robot_interface::msg::PositionFeedback::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_PositionFeedback_voltage(msg_);
  }

private:
  ::robot_interface::msg::PositionFeedback msg_;
};

class Init_PositionFeedback_torque
{
public:
  explicit Init_PositionFeedback_torque(::robot_interface::msg::PositionFeedback & msg)
  : msg_(msg)
  {}
  Init_PositionFeedback_position torque(::robot_interface::msg::PositionFeedback::_torque_type arg)
  {
    msg_.torque = std::move(arg);
    return Init_PositionFeedback_position(msg_);
  }

private:
  ::robot_interface::msg::PositionFeedback msg_;
};

class Init_PositionFeedback_speed
{
public:
  Init_PositionFeedback_speed()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PositionFeedback_torque speed(::robot_interface::msg::PositionFeedback::_speed_type arg)
  {
    msg_.speed = std::move(arg);
    return Init_PositionFeedback_torque(msg_);
  }

private:
  ::robot_interface::msg::PositionFeedback msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interface::msg::PositionFeedback>()
{
  return robot_interface::msg::builder::Init_PositionFeedback_speed();
}

}  // namespace robot_interface

#endif  // ROBOT_INTERFACE__MSG__DETAIL__POSITION_FEEDBACK__BUILDER_HPP_
