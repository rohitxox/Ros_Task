// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interface:msg/ObjectClassification.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__STRUCT_HPP_
#define ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__robot_interface__msg__ObjectClassification __attribute__((deprecated))
#else
# define DEPRECATED__robot_interface__msg__ObjectClassification __declspec(deprecated)
#endif

namespace robot_interface
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ObjectClassification_
{
  using Type = ObjectClassification_<ContainerAllocator>;

  explicit ObjectClassification_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->label = "";
      this->probability = 0.0;
      this->x_min = 0ll;
      this->y_min = 0ll;
      this->x_max = 0ll;
      this->y_max = 0ll;
    }
  }

  explicit ObjectClassification_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : label(_alloc),
    header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->label = "";
      this->probability = 0.0;
      this->x_min = 0ll;
      this->y_min = 0ll;
      this->x_max = 0ll;
      this->y_max = 0ll;
    }
  }

  // field types and members
  using _label_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _label_type label;
  using _probability_type =
    double;
  _probability_type probability;
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _x_min_type =
    int64_t;
  _x_min_type x_min;
  using _y_min_type =
    int64_t;
  _y_min_type y_min;
  using _x_max_type =
    int64_t;
  _x_max_type x_max;
  using _y_max_type =
    int64_t;
  _y_max_type y_max;

  // setters for named parameter idiom
  Type & set__label(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->label = _arg;
    return *this;
  }
  Type & set__probability(
    const double & _arg)
  {
    this->probability = _arg;
    return *this;
  }
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__x_min(
    const int64_t & _arg)
  {
    this->x_min = _arg;
    return *this;
  }
  Type & set__y_min(
    const int64_t & _arg)
  {
    this->y_min = _arg;
    return *this;
  }
  Type & set__x_max(
    const int64_t & _arg)
  {
    this->x_max = _arg;
    return *this;
  }
  Type & set__y_max(
    const int64_t & _arg)
  {
    this->y_max = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interface::msg::ObjectClassification_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interface::msg::ObjectClassification_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interface::msg::ObjectClassification_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interface::msg::ObjectClassification_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interface__msg__ObjectClassification
    std::shared_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interface__msg__ObjectClassification
    std::shared_ptr<robot_interface::msg::ObjectClassification_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ObjectClassification_ & other) const
  {
    if (this->label != other.label) {
      return false;
    }
    if (this->probability != other.probability) {
      return false;
    }
    if (this->header != other.header) {
      return false;
    }
    if (this->x_min != other.x_min) {
      return false;
    }
    if (this->y_min != other.y_min) {
      return false;
    }
    if (this->x_max != other.x_max) {
      return false;
    }
    if (this->y_max != other.y_max) {
      return false;
    }
    return true;
  }
  bool operator!=(const ObjectClassification_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ObjectClassification_

// alias to use template instance with default allocator
using ObjectClassification =
  robot_interface::msg::ObjectClassification_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interface

#endif  // ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__STRUCT_HPP_
