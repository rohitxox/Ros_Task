// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interface:msg/ObjectClassification.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__BUILDER_HPP_
#define ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interface/msg/detail/object_classification__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interface
{

namespace msg
{

namespace builder
{

class Init_ObjectClassification_y_max
{
public:
  explicit Init_ObjectClassification_y_max(::robot_interface::msg::ObjectClassification & msg)
  : msg_(msg)
  {}
  ::robot_interface::msg::ObjectClassification y_max(::robot_interface::msg::ObjectClassification::_y_max_type arg)
  {
    msg_.y_max = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

class Init_ObjectClassification_x_max
{
public:
  explicit Init_ObjectClassification_x_max(::robot_interface::msg::ObjectClassification & msg)
  : msg_(msg)
  {}
  Init_ObjectClassification_y_max x_max(::robot_interface::msg::ObjectClassification::_x_max_type arg)
  {
    msg_.x_max = std::move(arg);
    return Init_ObjectClassification_y_max(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

class Init_ObjectClassification_y_min
{
public:
  explicit Init_ObjectClassification_y_min(::robot_interface::msg::ObjectClassification & msg)
  : msg_(msg)
  {}
  Init_ObjectClassification_x_max y_min(::robot_interface::msg::ObjectClassification::_y_min_type arg)
  {
    msg_.y_min = std::move(arg);
    return Init_ObjectClassification_x_max(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

class Init_ObjectClassification_x_min
{
public:
  explicit Init_ObjectClassification_x_min(::robot_interface::msg::ObjectClassification & msg)
  : msg_(msg)
  {}
  Init_ObjectClassification_y_min x_min(::robot_interface::msg::ObjectClassification::_x_min_type arg)
  {
    msg_.x_min = std::move(arg);
    return Init_ObjectClassification_y_min(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

class Init_ObjectClassification_header
{
public:
  explicit Init_ObjectClassification_header(::robot_interface::msg::ObjectClassification & msg)
  : msg_(msg)
  {}
  Init_ObjectClassification_x_min header(::robot_interface::msg::ObjectClassification::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ObjectClassification_x_min(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

class Init_ObjectClassification_probability
{
public:
  explicit Init_ObjectClassification_probability(::robot_interface::msg::ObjectClassification & msg)
  : msg_(msg)
  {}
  Init_ObjectClassification_header probability(::robot_interface::msg::ObjectClassification::_probability_type arg)
  {
    msg_.probability = std::move(arg);
    return Init_ObjectClassification_header(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

class Init_ObjectClassification_label
{
public:
  Init_ObjectClassification_label()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ObjectClassification_probability label(::robot_interface::msg::ObjectClassification::_label_type arg)
  {
    msg_.label = std::move(arg);
    return Init_ObjectClassification_probability(msg_);
  }

private:
  ::robot_interface::msg::ObjectClassification msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interface::msg::ObjectClassification>()
{
  return robot_interface::msg::builder::Init_ObjectClassification_label();
}

}  // namespace robot_interface

#endif  // ROBOT_INTERFACE__MSG__DETAIL__OBJECT_CLASSIFICATION__BUILDER_HPP_
