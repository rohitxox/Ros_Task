// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interface:msg/PositionFeedback.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__MSG__DETAIL__POSITION_FEEDBACK__STRUCT_H_
#define ROBOT_INTERFACE__MSG__DETAIL__POSITION_FEEDBACK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/PositionFeedback in the package robot_interface.
/**
  * PositionFeedback.msg
 */
typedef struct robot_interface__msg__PositionFeedback
{
  /// Unit of measure (e.g., meters per second)
  double speed;
  /// Unit of measure (e.g., Newton meters)
  double torque;
  /// Unit of measure (e.g., radians or meters)
  double position;
  /// Unit of measure (e.g., volts)
  double voltage;
  /// Timestamp in the header
  std_msgs__msg__Header header;
} robot_interface__msg__PositionFeedback;

// Struct for a sequence of robot_interface__msg__PositionFeedback.
typedef struct robot_interface__msg__PositionFeedback__Sequence
{
  robot_interface__msg__PositionFeedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interface__msg__PositionFeedback__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACE__MSG__DETAIL__POSITION_FEEDBACK__STRUCT_H_
