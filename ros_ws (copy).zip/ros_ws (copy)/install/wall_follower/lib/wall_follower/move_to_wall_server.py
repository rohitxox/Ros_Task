import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from rclpy.action import ActionServer
from wall_follower.action import MoveToWall

class MoveToWallServer(Node):
    def __init__(self):
        super().__init__('move_to_wall_server')
        self._action_server = ActionServer(
            self,
            MoveToWall,
            'move_to_wall',
            self.execute_callback)
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        self.subscription = self.create_subscription(
            LaserScan,
            'scan',
            self.scan_callback,
            10)
        self.current_distance = float('inf')

    def execute_callback(self, goal_handle):
        self.get_logger().info('Executing goal...')
        feedback_msg = MoveToWall.Feedback()

        while rclpy.ok():
            feedback_msg.current_distance = self.current_distance
            goal_handle.publish_feedback(feedback_msg)
            if self.current_distance <= goal_handle.request.distance_to_stop:
                goal_handle.succeed()
                result = MoveToWall.Result()
                result.success = True
                return result

            # Move towards the wall
            twist = Twist()
            if self.current_distance > goal_handle.request.distance_to_stop:
                twist.linear.x = 0.2
            else:
                twist.linear.x = 0.0
            self.publisher_.publish(twist)
            rclpy.sleep(0.1)

    def scan_callback(self, msg):
        # Assuming the front direction is the middle element
        self.current_distance = msg.ranges[len(msg.ranges) // 2]

def main(args=None):
    rclpy.init(args=args)
    move_to_wall_server = MoveToWallServer()
    rclpy.spin(move_to_wall_server)
    move_to_wall_server.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()