# test_import.py
try:
    from wall_follower.action import MoveToWall
    print("Import successful!")
except Exception as e:
    print("Error during import:", e)
