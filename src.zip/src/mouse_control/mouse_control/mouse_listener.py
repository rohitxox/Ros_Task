import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from pynput import mouse

speed = 0.1
turn_speed = 0.1  

class MouseController(Node):
    def __init__(self):
        super().__init__('mouse_controller')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        self.listener = mouse.Listener(on_move=self.on_move, on_click=self.on_click, on_scroll=self.on_scroll)
        self.listener.start()

    def on_move(self, x, y):
        # No action on mouse move
        pass

    def on_click(self, x, y, button, pressed):
        twist = Twist()
        if pressed:
            if button == mouse.Button.left:
                # Turn left
                twist.angular.z = turn_speed
            elif button == mouse.Button.right:
                # Turn right
                twist.angular.z = -turn_speed
            elif button == mouse.Button.button9:
                # Stop the robot when Button.button9 is pressed
                twist.linear.x = 0.0
                twist.angular.z = 0.0
        else:
            if button == mouse.Button.left or button == mouse.Button.right or button == mouse.Button.button9:
                twist.angular.z = 0.0
                twist.linear.x = 0.0
        self.publisher_.publish(twist)

    def on_scroll(self, x, y, dx, dy):
        twist = Twist()
        twist.linear.x = dy * speed
        print(f"Scrolling with dy={dy}: Setting linear.x to {twist.linear.x}")  
        self.publisher_.publish(twist)

    def stop(self):
        self.listener.stop()

def main(args=None):
    rclpy.init(args=args)
    mouse_controller = MouseController()
    rclpy.spin(mouse_controller)
    mouse_controller.stop()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
